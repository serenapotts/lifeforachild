update child set is_deleted = false;
update clinical_record set is_deleted = false;
update country set is_deleted = false;
update diabetes_centre set is_deleted = false;
update report set is_deleted = false;
update user set is_deleted = false;
update user_group set is_deleted = false;
update permissions set is_deleted = false;