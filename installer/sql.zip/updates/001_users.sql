insert into permissions (version, name) values (1, 'View Child Name');
insert into permissions (version, name) values (1, 'Add Child');
insert into permissions (version, name) values (1, 'Edit Child');
insert into permissions (version, name) values (1, 'Add Medical Record');
insert into permissions (version, name) values (1, 'Edit Medical Record');
insert into permissions (version, name) values (1, 'View Medical Record');
insert into permissions (version, name) values (1, 'User Administation');

insert into user_group (version, group_name) values (1, 'Program Manager');
insert into user_group (version, group_name) values (1, 'PMs Assistants');
insert into user_group (version, group_name) values (1, 'Data Entry Operators');
insert into user_group (version, group_name) values (1, 'Country Manager');
insert into user_group (version, group_name) values (1, 'Centre Admin');
insert into user_group (version, group_name) values (1, 'Centre Staff');
insert into user_group (version, group_name) values (1, 'Researchers');

insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Program Manager' and
name='User Administation');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='PMs Assistants' and
name='User Administation');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Country Manager' and
name='User Administation');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Admin' and
name='User Administation');

insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Country Manager' and
name='View Child Name');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Admin' and
name='View Child Name');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Staff' and
name='View Child Name');

insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Program Manager' and
name='Add Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='PMs Assistants' and
name='Add Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Data Entry Operators' and
name='Add Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Country Manager' and
name='Add Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Admin' and
name='Add Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Staff' and
name='Add Child');

insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Program Manager' and
name='Edit Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='PMs Assistants' and
name='Edit Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Data Entry Operators' and
name='Edit Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Country Manager' and
name='Edit Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Admin' and
name='Edit Child');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Staff' and
name='Edit Child');

insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Program Manager' and
name='Add Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='PMs Assistants' and
name='Add Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Data Entry Operators' and
name='Add Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Country Manager' and
name='Add Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Admin' and
name='Add Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Staff' and
name='Add Medical Record');

insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Program Manager' and
name='Edit Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='PMs Assistants' and
name='Edit Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Data Entry Operators' and
name='Edit Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Country Manager' and
name='Edit Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Admin' and
name='Edit Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Staff' and
name='Edit Medical Record');

insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Program Manager' and
name='View Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='PMs Assistants' and
name='View Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Country Manager' and
name='View Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Centre Admin' and
name='View Medical Record');
insert into user_group_permissions (user_group, permissions)
(select ug.id, p.id from user_group ug, permissions p
where ug.group_name='Researchers' and
name='View Medical Record');


-- Passw0rd
insert into user (version, username, password, enabled, user_group, is_deleted)
(select 1, 'admin', 'ebfc7910077770c8340f63cd2dca2ac1f120444f', true, ug.id, false from user_group ug
where ug.group_name='Program Manager');

update user set first_name ='admin', last_name='user' where username='admin';
