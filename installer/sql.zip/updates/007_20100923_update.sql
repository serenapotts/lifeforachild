update user_group set group_name ='Centre Manager' where group_name='Centre Admin';
update user_group set group_name ='Assistant to Program Manager' where group_name='PMs Assistants';